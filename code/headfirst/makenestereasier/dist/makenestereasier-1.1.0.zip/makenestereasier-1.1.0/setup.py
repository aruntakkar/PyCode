from distutils.core import setup

setup(
    name='makenestereasier',
    version='1.1.0',
    py_modules=['makenestereasier'],
    author='arun',
    author_email='aruntakkar5@gmail.com',
    description='A Simple Printer of nested lists'
)
