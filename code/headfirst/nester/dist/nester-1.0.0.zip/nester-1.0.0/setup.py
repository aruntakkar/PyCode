from distutils.core import setup

setup(
    name='nester',
    version='1.0.0',
    py_modules=['nester'],
    author='arun',
    author_email='aruntakkar5@gmail.com',
    description='A Simple Printer of nested lists'
)
