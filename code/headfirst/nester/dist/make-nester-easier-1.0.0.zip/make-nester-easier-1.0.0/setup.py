from distutils.core import setup

setup(
    name='make-nester-easier',
    version='1.0.0',
    py_modules=['make-nester-easier'],
    author='arun',
    author_email='aruntakkar5@gmail.com',
    description='A Simple Printer of nested lists'
)
