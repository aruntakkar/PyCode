from distutils.core import setup

setup(
    name="nesterstdout",
    version="1.1.0",
    py_modules=['nesterstdout'],
    author='arun',
    author_email='aruntakkar5@gmail.com',
    description='A small module to get the list from nested list and give the \
        standard output'
)
